import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { WeatherProvider } from '../../providers/weather/weather';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
	selector: 'page-settings',
	templateUrl: 'settings.html',
})
export class SettingsPage {
	weatherInfo: any[]; //Contains all the API info
	city: string;
	temperatureUnit: string;
	nbrNewsArticles: number; //Number of news articles to display in the home page

	constructor(public navCtrl: NavController, public navParams: NavParams, private wp:WeatherProvider,  private storage: Storage, public alertCtrl: AlertController) {
	}

	ionViewDidEnter(){ //Loads previous information to populate the options
						//Possibly bringing all of these under an array would look cleaner
		this.storage.get("city").then((data) =>{
			this.city = data;
		})		
		.catch((err) => {
			console.log("error with retrieving city from storage");
		})
		
		this.storage.get("temperatureUnit").then((data) => {
			this.temperatureUnit = data;
		})
		.catch((err) => {
			console.log("error with retrieving temperatureUnit from storage");
		})
		
		this.storage.get("numberOfNewsArticles").then((data) => {
			this.nbrNewsArticles = data;
		})
		.catch((err) => {
			console.log("error with retrieving numberOfNewsArticles from storage");
		})
		
	}
	
	saveData(){
		this.checkInput();

		this.wp.getWeather(this.city, this.temperatureUnit)
			.subscribe(data => {
				this.weatherInfo = data;
							
				this.storage.set("weatherInfoApi", data);
				this.storage.set("temperatureUnit", this.temperatureUnit);
				
				this.storage.set("country", data.sys.country);
				this.storage.set("city", this.city);

				this.storage.set("numberOfNewsArticles", this.nbrNewsArticles);
				
				this.navCtrl.pop();
		},
			(error) => { //Adapted from https://www.tektutorialshub.com/angular/angular-http-error-handling/#catching-errors-in-http-request
				this.storage.set("city", this.city);
				this.storage.set("weatherInfoApi", null);
				this.storage.set("numberOfNewsArticles", null);
				this.navCtrl.pop();
				
		})

	}

	checkInput(){ //sets the default information
		if(this.city == null){
			this.city = "Galway";
		}
		if(this.temperatureUnit == null){
			this.temperatureUnit = "metric";
		}
		if(this.nbrNewsArticles == null){
			this.nbrNewsArticles = 5;
		}

	}
	
	checkCity(){
		this.wp.getWeather(this.city, this.temperatureUnit)
			.subscribe(data => {
				this.showPositiveAlert();
			},
			(error) =>{
				this.showNegativeAlert();	
			})
	}
	
	async showNegativeAlert(){ //Adapted from https://www.javatpoint.com/ionic-alert
		const alert = await this.alertCtrl.create({  
			message: 'This city does not exist, please check the spelling and try again',  
			buttons: ['OK']  
		});  
		await alert.present();
	}
	
		async showPositiveAlert(){ //Adapted from https://www.javatpoint.com/ionic-alert
		const alert = await this.alertCtrl.create({  
			message: 'City exists!',  
			buttons: ['OK']  
		});  
		await alert.present();
	}
}
