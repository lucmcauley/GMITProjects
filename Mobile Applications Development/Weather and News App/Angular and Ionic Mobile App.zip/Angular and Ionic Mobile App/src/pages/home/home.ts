import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import { SettingsPage } from '../../pages/settings/settings';

import { NewsProvider } from '../../providers/news/news';

@Component({
	selector: 'page-home',
	templateUrl: 'home.html'
})
export class HomePage {
	//General data
	city: string;
	country: string;
	imageHidden: boolean = true;
	newsDisabled: boolean = true;
	newsHidden: boolean = false;
	
	//Data for the weather section
	weatherInfo: any; //Takes the entire weather API
	weatherInfoMain: any; //Takes the 'main' subsection of the WeatherInfo
	weatherTitle: string;
	weatherFeelsLike: number;
	weatherTitleArray: string[]; //Array taken from weatherInfo to then divide for the display information
	weatherSubtitle: string;
	weatherImageUrl: string;
	weatherTemp: number;
	displayTempUnit: string; // Used to display C, F or K
	
	//Data for the news section
	newsInfo: any; // Taked the entire news API
	numberOfArticlesToDisplay: number; //Set in the settings page, automatically set to 5
	totalNumberOfNewsArticles: number;
	articleDisplayInfo: any []; //Array containing the information on the news articles displayed in home page
	

	constructor(public navCtrl: NavController, private storage: Storage, private np: NewsProvider) {}
  
	ngOnInit(){ //Only for the first time to display empty page
		this.weatherTitle = "City not Found";
	}

	ionViewDidEnter(){
		this.newsHidden = false;
		this.updateWeather();
		
		this.storage.get("numberOfNewsArticles")
		.then((data) => {
			if(data == null){
				console.log("null news articles");
				this.newsDisabled = true;
			}else{
				this.numberOfArticlesToDisplay = data;
				this.newsDisabled = false;
			}
		})
		.catch((err) => {
			console.log("error with number of articles");
		})
	}

	updateWeather(){
		//Updates most of the weather info to be displayed
		this.storage.get("city")
		.then((data) =>{
			if(data == null){
				console.log("city is null");
				this.weatherTitle = "City not Found";
			} else {
				this.city = data;
			}
		}).catch((err) =>{
			console.log("error getting city");
		});
		
		this.storage.get("weatherInfoApi")
			.then((data) =>{
				if(data == null){
					console.log("Weather Data is null");
					this.weatherInfo = null;
					this.weatherInfoMain = null;
					this.imageHidden = true;
					
				} else {
					this.weatherInfo = data;
					this.weatherInfoMain = data.main;
					this.setWeatherInformation();
					this.imageHidden = false;
				}
			})
			.catch((err) => {
				console.log("error updating weather " + err);
			});

		//Temperature unit is not held in the API so must be stored separately
		this.storage.get("temperatureUnit")
			.then((data) => {
				if(data == null){
					console.log("temperature unit is null");
				} else {
					this.displayTempUnit = data;
					this.setDisplayUnit();
				}
			})
			.catch((err) => {
				console.log("error updating temperature unit " + err);
			});
	}
	
	setWeatherInformation(){
		this.weatherTitleArray = this.weatherInfo.weather.map(function(i) {
			//For whatever reason, this is turned into a two dimentional array
			return [i.main, i.description, i.id, i.icon];
		});			
		
		//I would rather use the left hand side variables on the html page but they are considered undefined so I have to set them here
		this.city = this.weatherInfo.name; //Used to capitalise and format for display
		this.country = this.weatherInfo.sys.country;
		
		this.weatherTitle = this.weatherTitleArray[0][0];
		this.weatherSubtitle = this.weatherTitleArray[0][1];
		this.weatherTemp = this.weatherInfo.main.temp;
		this.weatherFeelsLike = this.weatherInfo.main.feels_like;

		this.buildWeatherIconUrl(this.weatherTitleArray[0][3]);
	}
	
	updateNews(){
		this.np.getNews(this.country, this.numberOfArticlesToDisplay).subscribe((data) =>{
			this.newsInfo = data;
			this.totalNumberOfNewsArticles = this.newsInfo.totalResults;
			this.articleDisplayInfo = this.newsInfo.articles;
			
			this.newsHidden = !this.newsHidden; //Used in the HTML page to display the news articles
		});
	}

	buildWeatherIconUrl(icon: string){ //Icon displayed on the HTML page
		this.weatherImageUrl =  `http://openweathermap.org/img/wn/${icon}@2x.png`;
	}
	
	setDisplayUnit(){ //The below are displayed on the 
		if(this.displayTempUnit == "metric"){
			this.displayTempUnit = "C";
		}else if(this.displayTempUnit == "imperial"){
			this.displayTempUnit = "F";
		}else if(this.displayTempUnit == "standard") {
			this.displayTempUnit = "K";
		}
	}

  
	goToSettings(){
		this.navCtrl.push(SettingsPage);
	}
}
