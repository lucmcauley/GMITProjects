import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

/*
  Generated class for the NewsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/

@Injectable()
export class NewsProvider {

	constructor(public http: HttpClient) {}
  
	getNews(country: string, nmbrItems: number): Observable<any>{
	  
		return this.http.get(`https://newsapi.org/v2/top-headlines?country=${country}&pageSize=${nmbrItems}&apiKey=cf29781f71394a98bca1dd63fbd1e1e4`)
	  
	}

}
